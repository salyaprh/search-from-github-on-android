package com.example.androidfundamentalsalya.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.androidfundamentalsalya.data.response.ListFollowingResponseItem
import com.example.androidfundamentalsalya.databinding.ItemUserBinding

class FollowingAdapter(private val clickListener: RecyclerViewItemClickListener) : ListAdapter<ListFollowingResponseItem, FollowingAdapter.MyViewHolder>(
    DIFF_CALLBACK
) {

    interface RecyclerViewItemClickListener {
        fun onItemClick(dataList: ListFollowingResponseItem)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val review = getItem(position)
        holder.bind(review)

        holder.itemView.setOnClickListener {
            clickListener.onItemClick(review)
        }
    }

    class MyViewHolder(val binding: ItemUserBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(review: ListFollowingResponseItem){
            binding.tvItemName.text = review.login

            Glide.with(binding.root)
                .load(review.avatarUrl)
                .into(binding.imgItemPhoto)
        }
    }

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ListFollowingResponseItem>() {
            override fun areItemsTheSame(oldItem: ListFollowingResponseItem, newItem: ListFollowingResponseItem): Boolean {
                return oldItem == newItem
            }
            override fun areContentsTheSame(oldItem: ListFollowingResponseItem, newItem: ListFollowingResponseItem): Boolean {
                return oldItem == newItem
            }
        }
    }
}
