package com.example.androidfundamentalsalya.model

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.androidfundamentalsalya.data.response.DetailUserResponse
import com.example.androidfundamentalsalya.data.response.ListFollowerResponseItem
import com.example.androidfundamentalsalya.data.retrofit.ApiConfig
import com.example.androidfundamentalsalya.utils.Event
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel3 : ViewModel() {

    private var parameterQ: String = ""

    fun setParameterQ(value: String) {
        parameterQ = value

        getListUser(parameterQ)
    }

    private val _listItem = MutableLiveData<List<ListFollowerResponseItem>>()
    val listItem: LiveData<List<ListFollowerResponseItem>> = _listItem

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _snackbarText = MutableLiveData<Event<String>>()
    val snackbarText: LiveData<Event<String>> = _snackbarText

    private fun getListUser(parameterQ: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val response = withContext(Dispatchers.IO) {
                    ApiConfig.getApiService().getUserFollower(parameterQ).execute()
                }
                if (response.isSuccessful) {
                    _listItem.value = response.body()
                } else {
                    Log.e(TAG, "onFailure(1): ${response.message()}")
                    _snackbarText.value = Event("Data gagal dimuat")
                }
            } catch (e: Exception) {
                Log.e(TAG, "onFailure(2): ${e.message}", e)
                _snackbarText.value = Event("Data gagal dimuat")
            } finally {
                _isLoading.value = false
            }
        }
    }

    companion object{
        private const val TAG = "MainViewModel3"
    }

}
