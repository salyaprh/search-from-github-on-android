package com.example.androidfundamentalsalya.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.androidfundamentalsalya.R
import com.example.androidfundamentalsalya.SettingPreferences
import com.example.androidfundamentalsalya.adapter.UserAdapter
import com.example.androidfundamentalsalya.data.response.ItemsItem
import com.example.androidfundamentalsalya.data.response.UserResponse
import com.example.androidfundamentalsalya.dataStore
import com.example.androidfundamentalsalya.databinding.ActivityMainBinding
import com.example.androidfundamentalsalya.model.MainViewModel
import com.example.androidfundamentalsalya.model.ThemeViewModel
import com.example.androidfundamentalsalya.model.ViewModelFactory
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity(), UserAdapter.RecyclerViewItemClickListener {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val pref = SettingPreferences.getInstance(application.dataStore)
        val themeViewModel = ViewModelProvider(this, ViewModelFactory(pref)).get(
            ThemeViewModel::class.java
        )
        themeViewModel.getThemeSettings().observe(this) { isDarkModeActive: Boolean ->
            if (isDarkModeActive) {
                binding.menu.setImageResource(R.drawable.baseline_menu_24)
            } else {
                binding.menu.setImageResource(R.drawable.baseline_menu_24_light)
            }
        }

        val mainViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            MainViewModel::class.java)
        mainViewModel.setParameterQ("")
        mainViewModel.user.observe(this) { user ->
            cekData(user)
        }
        mainViewModel.isLoading.observe(this) {
            showLoading(it)
        }

        with(binding) {
            searchView.setupWithSearchBar(searchBar)
            searchView
                .editText
                .setOnEditorActionListener { textView, actionId, event ->
                    val searchString = searchView.text.toString().trim()

                    if (searchString.isEmpty()) {
                        Snackbar.make(
                            window.decorView.rootView,
                            "Masukkan minimal 1 huruf...",
                            Snackbar.LENGTH_SHORT
                        ).show()
                    } else {
                        searchBar.setText(searchString)
                        searchView.hide()

                        mainViewModel.setParameterQ(searchString)
                    }

                    false
                }
        }

        val layoutManager = LinearLayoutManager(this)
        binding.rvUser.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.rvUser.addItemDecoration(itemDecoration)

        val optionButton = binding.menu
        optionButton.setOnClickListener { v ->
            showPopupMenu(v)
        }

    }

    private fun cekData(user: UserResponse) {
        val totalCount = user.totalCount
        val mainViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(MainViewModel::class.java)

        if (totalCount > 0) {
            binding.tvMessage.visibility = View.GONE
            observeViewModel(mainViewModel)
        } else {
            showNoDataMessage()
        }
    }

    private fun observeViewModel(mainViewModel: MainViewModel) {
        mainViewModel.listItem.observe(this) { listItem ->
            setUserListData(listItem)
        }
        mainViewModel.isLoading.observe(this) {
            showLoading(it)
        }
    }

    private fun showNoDataMessage() {
        binding.tvMessage.text = getString(R.string.data_not_found)
        binding.tvMessage.visibility = View.VISIBLE
        Snackbar.make(
            window.decorView.rootView,
            getString(R.string.data_not_found),
            Snackbar.LENGTH_SHORT
        ).show()
    }


    private fun handleUserListData(totalCount: Int, listItem: List<ItemsItem>) {
        if (totalCount > 0) {
            binding.tvMessage.visibility = View.GONE
            setUserListData(listItem)
        } else {
            binding.tvMessage.text = getString(R.string.data_not_found)
            binding.tvMessage.visibility = View.VISIBLE

            Snackbar.make(
                window.decorView.rootView,
                getString(R.string.data_not_found),
                Snackbar.LENGTH_SHORT
            ).show()
        }
    }


    private fun setUserListData(userList: List<ItemsItem>) {
        val adapter = UserAdapter(this)
        adapter.submitList(userList)
        binding.rvUser.adapter = adapter
    }

    override fun onItemClick(userItem: ItemsItem) {
        val intent = Intent(this, DetailUser::class.java)
        intent.putExtra("LOGIN", userItem.login)
        intent.putExtra("AVATAR_URL", userItem.avatarUrl)
        startActivity(intent)
    }

    private fun showLoading(isLoading: Boolean) {
        binding.tvMessage.visibility = View.GONE
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    fun showPopupMenu(view: View) {
        val popupMenu = PopupMenu(this, view)
        popupMenu.inflate(R.menu.option_menu)

        popupMenu.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.menu_favorit -> {
                    val intent = Intent(this, FavoritActivity::class.java)
                    startActivity(intent)

                    true
                }
                R.id.menu_tema -> {
                    val intent = Intent(this, ThemeActivity::class.java)
                    startActivity(intent)

                    true
                }
                else -> false
            }
        }

        popupMenu.show()
    }
}