package com.example.androidfundamentalsalya.data.retrofit

import com.example.androidfundamentalsalya.data.response.DetailUserResponse
import com.example.androidfundamentalsalya.data.response.ListFollowerResponseItem
import com.example.androidfundamentalsalya.data.response.ListFollowingResponseItem
import com.example.androidfundamentalsalya.data.response.UserResponse
import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @GET("search/users")
    fun getUserList(
        @Query("q") q: String
    ): Call<UserResponse>

    @GET("users/{login}")
    fun getUserDetail(
        @Path("login") login: String
    ): Call<DetailUserResponse>

    @GET("users/{login}/followers")
    fun getUserFollower(
        @Path("login") login: String
    ): Call<List<ListFollowerResponseItem>>

    @GET("users/{login}/following")
    fun getUserFollowing(
        @Path("login") login: String
    ): Call<List<ListFollowingResponseItem>>
}
