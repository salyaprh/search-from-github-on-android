package com.example.androidfundamentalsalya.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.androidfundamentalsalya.data.response.ItemsItem
import com.example.androidfundamentalsalya.databinding.ItemUserBinding

class UserAdapter(private val clickListener: RecyclerViewItemClickListener) : ListAdapter<ItemsItem, UserAdapter.MyViewHolder>(DIFF_CALLBACK) {

    interface RecyclerViewItemClickListener {
        fun onItemClick(userItem: ItemsItem)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val userItem = getItem(position)
        holder.bind(userItem)
    }

    inner class MyViewHolder(private val binding: ItemUserBinding) : RecyclerView.ViewHolder(binding.root) {

        init {
            binding.root.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    val userItem = getItem(position)
                    clickListener.onItemClick(userItem)
                }
            }
        }

        fun bind(userItem: ItemsItem) {
            binding.tvItemName.text = userItem.login

            Glide.with(binding.root)
                .load(userItem.avatarUrl)
                .into(binding.imgItemPhoto)
        }
    }

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ItemsItem>() {
            override fun areItemsTheSame(oldItem: ItemsItem, newItem: ItemsItem): Boolean {
                // Adjust this logic according to your ItemsItem class
                return oldItem.login == newItem.login
            }
            override fun areContentsTheSame(oldItem: ItemsItem, newItem: ItemsItem): Boolean {
                return oldItem == newItem
            }
        }
    }
}


