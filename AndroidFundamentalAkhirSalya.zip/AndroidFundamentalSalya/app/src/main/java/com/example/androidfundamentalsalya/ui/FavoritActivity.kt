package com.example.androidfundamentalsalya.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.androidfundamentalsalya.adapter.FavoritAdapter
import com.example.androidfundamentalsalya.databinding.ActivityFavoritBinding
import com.example.androidfundamentalsalya.model.FavoritViewModel
import com.example.androidfundamentalsalya.model.ViewModelFactory2

class FavoritActivity : AppCompatActivity() {

    private var _activityFavoritBinding: ActivityFavoritBinding? = null
    private val binding get() = _activityFavoritBinding
    private lateinit var adapter: FavoritAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        _activityFavoritBinding = ActivityFavoritBinding.inflate(layoutInflater)
        setContentView(binding?.root)

        adapter = FavoritAdapter()
        setupRecyclerView()
        setupViewModel()
    }

    private fun setupRecyclerView() {
        binding?.rvFav?.apply {
            layoutManager = LinearLayoutManager(this@FavoritActivity)
            setHasFixedSize(true)
            adapter = this@FavoritActivity.adapter
        }
    }

    private fun setupViewModel() {
        val mainViewModel = obtainViewModel(this@FavoritActivity)
        mainViewModel.getAllFavorites().observe(this) { favoritList ->
            favoritList?.let {
                adapter.setListFavorites(it)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _activityFavoritBinding = null
    }

    private fun obtainViewModel(activity: AppCompatActivity): FavoritViewModel {
        val factory = ViewModelFactory2.getInstance(activity.application)
        return ViewModelProvider(activity, factory).get(FavoritViewModel::class.java)
    }

}
