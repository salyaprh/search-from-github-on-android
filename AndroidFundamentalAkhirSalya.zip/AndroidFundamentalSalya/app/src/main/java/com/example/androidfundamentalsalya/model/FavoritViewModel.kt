package com.example.androidfundamentalsalya.model

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.androidfundamentalsalya.database.Favorit
import com.example.androidfundamentalsalya.repository.FavoritRepository

class FavoritViewModel(application: Application) : ViewModel() {

    private val mFavoritRepository: FavoritRepository = FavoritRepository(application)

    fun getAllFavorites(): LiveData<List<Favorit>> = mFavoritRepository.getAllFavorites()

    fun search(login :String): LiveData<List<Favorit>> = mFavoritRepository.search(login)

}
