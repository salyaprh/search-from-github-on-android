package com.example.androidfundamentalsalya.model

import android.annotation.SuppressLint
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.androidfundamentalsalya.data.response.ItemsItem
import com.example.androidfundamentalsalya.data.response.UserResponse
import com.example.androidfundamentalsalya.data.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import com.example.androidfundamentalsalya.utils.Event
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class MainViewModel : ViewModel() {

    private var parameterQ: String = ""

    fun setParameterQ(value: String) {
        parameterQ = value

        getListUser(parameterQ)
    }

    private val _user = MutableLiveData<UserResponse>()
    val user: LiveData<UserResponse> = _user

    private val _listItem = MutableLiveData<List<ItemsItem>>()
    val listItem: LiveData<List<ItemsItem>> = _listItem

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _snackbarText = MutableLiveData<Event<String>>()
    val snackbarText: LiveData<Event<String>> = _snackbarText

    @SuppressLint("NullSafeMutableLiveData")
    private fun getListUser(parameterQ: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val response = withContext(Dispatchers.IO) {
                    ApiConfig.getApiService().getUserList(parameterQ).execute()
                }
                if (response.isSuccessful) {
                    val userResponse = response.body()
                    _user.value = userResponse
                    _listItem.value = userResponse?.items ?: emptyList()
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                    _snackbarText.value = Event("Data gagal dimuat")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error: ${e.message}", e)
                _snackbarText.value = Event("Data gagal dimuat")
            } finally {
                _isLoading.value = false
            }
        }
    }


    companion object{
        private const val TAG = "MainViewModel"
    }
}
