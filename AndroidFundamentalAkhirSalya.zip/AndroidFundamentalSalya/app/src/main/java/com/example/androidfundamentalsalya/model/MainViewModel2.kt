package com.example.androidfundamentalsalya.model

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.androidfundamentalsalya.data.response.DetailUserResponse
import com.example.androidfundamentalsalya.data.retrofit.ApiConfig
import com.example.androidfundamentalsalya.utils.Event
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel2 : ViewModel() {

    private var parameterLogin: String = ""

    fun setParameterLogin(value: String) {
        parameterLogin = value

        getUserDetail(parameterLogin)
    }

    private val _userDetail = MutableLiveData<DetailUserResponse>()
    val userDetail: LiveData<DetailUserResponse> = _userDetail

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _snackbarText = MutableLiveData<Event<String>>()
    val snackbarText: LiveData<Event<String>> = _snackbarText

    private fun getUserDetail(parameterLogin: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val response = withContext(Dispatchers.IO) {
                    ApiConfig.getApiService().getUserDetail(parameterLogin).execute()
                }
                if (response.isSuccessful) {
                    _userDetail.value = response.body()
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                    _snackbarText.value = Event("Data gagal dimuat")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error: ${e.message}", e)
                _snackbarText.value = Event("Data gagal dimuat")
            } finally {
                _isLoading.value = false
            }
        }
    }

    companion object{
        private const val TAG = "MainViewModel2"
    }

}
