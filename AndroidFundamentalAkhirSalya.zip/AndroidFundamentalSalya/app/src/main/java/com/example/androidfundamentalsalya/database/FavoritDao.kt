package com.example.androidfundamentalsalya.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface FavoritDao {
    @Query("SELECT * from favorit WHERE login = :login")
    fun search(login: String): LiveData<List<Favorit>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insert(favorit: Favorit)

    @Delete
    fun delete(favorit: Favorit)

    @Query("SELECT * from favorit ORDER BY id ASC")
    fun getAllFavorites(): LiveData<List<Favorit>>
}