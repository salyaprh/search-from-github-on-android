package com.example.androidfundamentalsalya.helper

import androidx.recyclerview.widget.DiffUtil
import com.example.androidfundamentalsalya.database.Favorit

class FavoritDiffCallback(private val oldFavoritList: List<Favorit>, private val newFavoritList: List<Favorit>) : DiffUtil.Callback() {

    override fun getOldListSize(): Int = oldFavoritList.size

    override fun getNewListSize(): Int = newFavoritList.size

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        return oldFavoritList[oldItemPosition].id == newFavoritList[newItemPosition].id
    }

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        val oldFavorit = oldFavoritList[oldItemPosition]
        val newFavorit = newFavoritList[newItemPosition]

        return oldFavorit.login == newFavorit.login && oldFavorit.avatarUrl == newFavorit.avatarUrl
    }
}
