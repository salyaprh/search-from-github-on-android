package com.example.androidfundamentalsalya.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.androidfundamentalsalya.database.Favorit
import com.example.androidfundamentalsalya.databinding.ItemFavoritBinding
import com.example.androidfundamentalsalya.helper.FavoritDiffCallback
import com.example.androidfundamentalsalya.ui.DetailUser

class FavoritAdapter : RecyclerView.Adapter<FavoritAdapter.FavoritViewHolder>() {

    private val listFavorites = ArrayList<Favorit>()

    fun setListFavorites(listFavorites: List<Favorit>) {
        val diffCallback = FavoritDiffCallback(this.listFavorites, listFavorites)
        val diffResult = DiffUtil.calculateDiff(diffCallback)
        this.listFavorites.clear()
        this.listFavorites.addAll(listFavorites)
        diffResult.dispatchUpdatesTo(this)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoritViewHolder {
        val binding = ItemFavoritBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FavoritViewHolder(binding)
    }

    override fun onBindViewHolder(holder: FavoritViewHolder, position: Int) {
        holder.bind(listFavorites[position])
    }
    override fun getItemCount(): Int {
        return listFavorites.size
    }

    inner class FavoritViewHolder(private val binding: ItemFavoritBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(favorit: Favorit) {
            binding.tvItemName.text = favorit.login
            Glide.with(binding.root)
                .load(favorit.avatarUrl)
                .into(binding.imgItemPhoto)
            binding.cvItem.setOnClickListener {
                val intent = Intent(it.context, DetailUser::class.java )
                intent.putExtra("LOGIN", favorit.login)
                intent.putExtra("AVATAR_URL", favorit.avatarUrl)
                intent.putExtra(DetailUser.EXTRA_FAVORIT, favorit)
                it.context.startActivity(intent)
            }
        }
    }
}
