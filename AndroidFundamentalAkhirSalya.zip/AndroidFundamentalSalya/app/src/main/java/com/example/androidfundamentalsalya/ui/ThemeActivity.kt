package com.example.androidfundamentalsalya.ui

import android.os.Bundle
import android.widget.CompoundButton
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.ViewModelProvider
import com.example.androidfundamentalsalya.R
import com.example.androidfundamentalsalya.SettingPreferences
import com.example.androidfundamentalsalya.dataStore
import com.example.androidfundamentalsalya.model.ThemeViewModel
import com.example.androidfundamentalsalya.model.ViewModelFactory
import com.google.android.material.switchmaterial.SwitchMaterial

class ThemeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_theme)

        val switchTheme = findViewById<SwitchMaterial>(R.id.switch_theme)

        initializeThemeViewModel(switchTheme)
    }

    private fun initializeThemeViewModel(switchTheme: SwitchMaterial) {
        val pref = SettingPreferences.getInstance(application.dataStore)
        val themeViewModel = ViewModelProvider(this, ViewModelFactory(pref)).get(
            ThemeViewModel::class.java
        )
        observeThemeSettings(themeViewModel, switchTheme)
        setupThemeSwitchListener(themeViewModel, switchTheme)
    }

    private fun observeThemeSettings(themeViewModel: ThemeViewModel, switchTheme: SwitchMaterial) {
        themeViewModel.getThemeSettings().observe(this) { isDarkModeActive: Boolean ->
            updateTheme(isDarkModeActive, switchTheme)
        }
    }

    private fun updateTheme(isDarkModeActive: Boolean, switchTheme: SwitchMaterial) {
        if (isDarkModeActive) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            switchTheme.isChecked = true
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            switchTheme.isChecked = false
        }
    }

    private fun setupThemeSwitchListener(themeViewModel: ThemeViewModel, switchTheme: SwitchMaterial) {
        switchTheme.setOnCheckedChangeListener { _: CompoundButton?, isChecked: Boolean ->
            themeViewModel.saveThemeSetting(isChecked)
        }
    }
}
