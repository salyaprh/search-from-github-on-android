package com.example.androidfundamentalsalya.model

import android.app.Application
import androidx.lifecycle.ViewModel
import com.example.androidfundamentalsalya.database.Favorit
import com.example.androidfundamentalsalya.repository.FavoritRepository

class FavoritAddUpdateViewModel(application: Application) : ViewModel() {

    private val mFavoritRepository: FavoritRepository = FavoritRepository(application)

    fun search(login :String) {
        mFavoritRepository.search(login)
    }

    fun insert(favorit: Favorit) {
        mFavoritRepository.insert(favorit)
    }

    fun delete(favorit: Favorit) {
        mFavoritRepository.delete(favorit)
    }
}
