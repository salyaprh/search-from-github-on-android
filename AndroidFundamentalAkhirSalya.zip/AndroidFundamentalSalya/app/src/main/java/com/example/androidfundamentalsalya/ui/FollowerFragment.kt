package com.example.androidfundamentalsalya.ui

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.androidfundamentalsalya.R
import com.example.androidfundamentalsalya.adapter.FollowerAdapter
import com.example.androidfundamentalsalya.data.response.ListFollowerResponseItem
import com.example.androidfundamentalsalya.databinding.FragmentFollowerBinding
import com.example.androidfundamentalsalya.model.MainViewModel3

class FollowerFragment : Fragment(), FollowerAdapter.RecyclerViewItemClickListener {

    private var _binding: FragmentFollowerBinding? = null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentFollowerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val loginId = requireActivity().intent.getStringExtra("LOGIN")
        setupRecyclerView()
        setupViewModel(loginId)
    }

    private fun setupRecyclerView() {
        val layoutManager = LinearLayoutManager(requireContext())
        binding.rvFollower.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(requireContext(), layoutManager.orientation)
        binding.rvFollower.addItemDecoration(itemDecoration)
    }

    private fun setupViewModel(loginId: String?) {
        val mainViewModel = ViewModelProvider(requireActivity()).get(MainViewModel3::class.java)
        mainViewModel.setParameterQ(loginId.toString())
        observeViewModel(mainViewModel)
    }

    private fun observeViewModel(mainViewModel: MainViewModel3) {
        mainViewModel.listItem.observe(viewLifecycleOwner) { listItem ->
            setUserListData(listItem)
        }
        mainViewModel.isLoading.observe(viewLifecycleOwner) {
            showLoading(it)
        }
    }

    override fun onItemClick(dataList: ListFollowerResponseItem) {
        val intent = Intent(requireContext(), DetailUser::class.java).apply {
            putExtra("LOGIN", dataList.login)
            putExtra("AVATAR_URL", dataList.avatarUrl)
        }
        startActivity(intent)
    }

    private fun setUserListData(userList: List<ListFollowerResponseItem>) {
        if (userList.isEmpty()) {
            binding.tvProggress.text = getString(R.string.data_not_found)
            binding.tvProggress.visibility = View.VISIBLE
        } else {
            binding.tvProggress.visibility = View.GONE
            val adapter = FollowerAdapter(this)
            adapter.submitList(userList)
            binding.rvFollower.adapter = adapter
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.tvProggress.visibility = View.GONE
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

}
