package com.example.androidfundamentalsalya.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.androidfundamentalsalya.data.response.ListFollowerResponseItem
import com.example.androidfundamentalsalya.databinding.ItemUserBinding

class FollowerAdapter(private val clickListener: RecyclerViewItemClickListener) : ListAdapter<ListFollowerResponseItem, FollowerAdapter.MyViewHolder>(
    DIFF_CALLBACK
) {

    interface RecyclerViewItemClickListener {
        fun onItemClick(dataList: ListFollowerResponseItem)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val review = getItem(position)
        holder.bind(review)

        holder.itemView.setOnClickListener {
            clickListener.onItemClick(review)
        }
    }

    class MyViewHolder(val binding: ItemUserBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(review: ListFollowerResponseItem){
            binding.tvItemName.text = review.login

            Glide.with(binding.root)
                .load(review.avatarUrl)
                .into(binding.imgItemPhoto)
        }
    }

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ListFollowerResponseItem>() {
            override fun areItemsTheSame(oldItem: ListFollowerResponseItem, newItem: ListFollowerResponseItem): Boolean {
                return oldItem == newItem
            }
            override fun areContentsTheSame(oldItem: ListFollowerResponseItem, newItem: ListFollowerResponseItem): Boolean {
                return oldItem == newItem
            }
        }
    }

}
