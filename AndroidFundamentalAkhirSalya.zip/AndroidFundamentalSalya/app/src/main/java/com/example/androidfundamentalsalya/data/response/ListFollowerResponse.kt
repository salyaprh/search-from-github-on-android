package com.example.androidfundamentalsalya.data.response

import com.google.gson.annotations.SerializedName

data class ListFollowerResponse(
	@field:SerializedName("ListFollowerResponse")
	val listFollowerResponse: List<ListFollowerResponseItem>
)

data class ListFollowerResponseItem(

	@field:SerializedName("login")
	val login: String,

	@field:SerializedName("avatar_url")
	val avatarUrl: String

)
