package com.example.androidfundamentalsalya.repository

import android.app.Application
import androidx.lifecycle.LiveData
import com.example.androidfundamentalsalya.database.Favorit
import com.example.androidfundamentalsalya.database.FavoritDao
import com.example.androidfundamentalsalya.database.FavoritRoomDatabase
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class FavoritRepository(application: Application) {
    private val mFavoritDao: FavoritDao
    private val executorService: ExecutorService = Executors.newSingleThreadExecutor()

    init {
        val db = FavoritRoomDatabase.getDatabase(application)
        mFavoritDao = db.favoritDao()
    }

    fun getAllFavorites(): LiveData<List<Favorit>> = mFavoritDao.getAllFavorites()

    fun search(login :String): LiveData<List<Favorit>> = mFavoritDao.search(login)

    fun insert(favorit: Favorit) {
        executorService.execute { mFavoritDao.insert(favorit) }
    }

    fun delete(favorit: Favorit) {
        executorService.execute { mFavoritDao.delete(favorit) }
    }
}
