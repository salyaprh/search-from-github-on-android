package com.example.androidfundamentalsalya.ui

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.androidfundamentalsalya.R
import com.example.androidfundamentalsalya.adapter.SectionsPagerAdapter
import com.example.androidfundamentalsalya.data.response.DetailUserResponse
import com.example.androidfundamentalsalya.database.Favorit
import com.example.androidfundamentalsalya.databinding.ActivityDetailUserBinding
import com.example.androidfundamentalsalya.helper.DateHelper
import com.example.androidfundamentalsalya.model.FavoritAddUpdateViewModel
import com.example.androidfundamentalsalya.model.FavoritViewModel
import com.example.androidfundamentalsalya.model.MainViewModel2
import com.example.androidfundamentalsalya.model.ViewModelFactory2
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class DetailUser : AppCompatActivity() {

    private lateinit var binding: ActivityDetailUserBinding
    private val viewModelEdit by viewModels<MainViewModel2>()

    private var isFavorited = false
    private var favorit: Favorit? = null

    private lateinit var favoritAddUpdateViewModel: FavoritAddUpdateViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val sectionsPagerAdapter = SectionsPagerAdapter(this)
        val viewPager: ViewPager2 = findViewById(R.id.view_pager)
        viewPager.adapter = sectionsPagerAdapter
        val tabs: TabLayout = findViewById(R.id.tabs)
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()
        supportActionBar?.elevation = 0f

        val loginId = intent.getStringExtra("LOGIN")
        val avatarUrl = intent.getStringExtra("AVATAR_URL")

        viewModelEdit.setParameterLogin(loginId.toString())
        viewModelEdit.userDetail.observe(this) { userDetail ->
            setUserData(userDetail)
        }
        viewModelEdit.isLoading.observe(this) {
            showLoading(it)
        }
        viewModelEdit.snackbarText.observe(this) {
            it.getContentIfNotHandled()?.let { snackBarText ->
                Snackbar.make(
                    window.decorView.rootView,
                    snackBarText,
                    Snackbar.LENGTH_SHORT
                ).show()
            }
        }

        favoritAddUpdateViewModel = obtainViewModel(this@DetailUser)

        favorit = intent.getParcelableExtra(EXTRA_FAVORIT)

        if (favorit != null) {
            isFavorited = true
            binding.favAdd.setImageResource(R.drawable.baseline_favorite_24_light)

        } else {
            favorit = Favorit()

            val cekData = obtainViewModel2(this@DetailUser)
            cekData.search(loginId.toString()).observe(this) { favoritList ->

                if (favoritList != null && (!favoritList.isEmpty())) {
                    favorit.let { favorit ->
                        favorit?.id = favoritList[0].id
                        favorit?.date = favoritList[0].date
                    }
                    isFavorited = true
                    binding.favAdd.setImageResource(R.drawable.baseline_favorite_24_light)

                }else{
                    isFavorited = false
                    binding.favAdd.setImageResource(R.drawable.baseline_favorite_border_24_light)
                }
            }

        }

        binding?.favAdd?.setOnClickListener {
            val login = loginId.toString()
            val avatar = avatarUrl.toString()

            favorit.let { favorit ->
                favorit?.login = login
                favorit?.avatarUrl = avatar
            }

            if (isFavorited) {
                favoritAddUpdateViewModel.delete(favorit as Favorit)

                isFavorited = false
                binding.favAdd.setImageResource(R.drawable.baseline_favorite_border_24_light)

                Snackbar.make(
                    window.decorView.rootView,
                    getString(R.string.favorit_deleted),
                    Snackbar.LENGTH_SHORT
                ).show()
            } else {
                favorit.let { favorit ->
                    favorit?.date = DateHelper.getCurrentDate()
                }
                favoritAddUpdateViewModel.insert(favorit as Favorit)

                isFavorited = true
                binding.favAdd.setImageResource(R.drawable.baseline_favorite_24_light)

                Snackbar.make(
                    window.decorView.rootView,
                    getString(R.string.favorit_added),
                    Snackbar.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun setUserData(userDetail: DetailUserResponse) {
        with(binding) {
            tvName.text = userDetail.name
            tvLogin.text = userDetail.login
            tvFollower.text = "${userDetail.followers.toString()} Followers"
            tvFollowing.text = "${userDetail.following.toString()} Following"

            Glide.with(root.context)
                .load(userDetail.avatarUrl)
                .circleCrop()
                .into(ivAvatar)
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    private fun obtainViewModel(activity: AppCompatActivity): FavoritAddUpdateViewModel {
        val factory = ViewModelFactory2.getInstance(activity.application)
        return ViewModelProvider(activity, factory).get(FavoritAddUpdateViewModel::class.java)
    }

    private fun obtainViewModel2(activity: AppCompatActivity): FavoritViewModel {
        val factory = ViewModelFactory2.getInstance(activity.application)
        return ViewModelProvider(activity, factory).get(FavoritViewModel::class.java)
    }

    companion object {
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_text_1,
            R.string.tab_text_2
        )

        const val EXTRA_FAVORIT = "extra_favorit"
    }

}